const sideMenu = document.querySelector('aside');
const menuBtn = document.getElementById('menu-btn');
const closeBtn = document.getElementById('close-btn');

const darkMode = document.querySelector('.dark-mode');

menuBtn.addEventListener('click', () => {
    sideMenu.style.display = 'block';
});

closeBtn.addEventListener('click', () => {
    sideMenu.style.display = 'none';
});

darkMode.addEventListener('click', () => {
    document.body.classList.toggle('dark-mode-variables');
    darkMode.querySelector('span:nth-child(1)').classList.toggle('active');
    darkMode.querySelector('span:nth-child(2)').classList.toggle('active');
})

const logoutButton = document.querySelector('.sidebar a[href="#"]:last-child');
if (logoutButton) {
    logoutButton.addEventListener('click', function(event) {
        event.preventDefault();
        customAlert('Logging out...', '#28a745');
        setTimeout(() => {
            window.location.href = '../index.html'; // Redirect to index.html
        }, 2000); // Reduced delay to 2 seconds
    });
}

const newLoginButton = document.getElementById('new-login');
if (newLoginButton) {
    newLoginButton.addEventListener('click', function(event) {
        event.preventDefault();
        customAlert('Redirecting to login...', '#28a745');
        setTimeout(() => {
            window.location.href = '../index.html'; // Redirect to index.html
        }, 2000); // Reduced delay to 2 seconds
    });
}

const moreUserButton = document.getElementById('more-user');
if (moreUserButton) {
    moreUserButton.addEventListener('click', function(event) {
        event.preventDefault();
        customAlert('Redirecting to signup...', '#28a745');
        setTimeout(() => {
            window.location.href = '../signup.html'; // Redirect to signup.html
        }, 2000); // Reduced delay to 2 seconds
    });
}

const usersLink = document.getElementById('users-link');
const newUsersSection = document.querySelector('.new-users');
const mainContent = document.querySelector('main');
const sidebarLinks = document.querySelectorAll('.sidebar a');

if (usersLink && newUsersSection && mainContent) {
    usersLink.addEventListener('click', function(event) {
        event.preventDefault();
        mainContent.innerHTML = ''; // Clear main content
        mainContent.appendChild(newUsersSection); // Append only the new users section

        // Remove active class from all sidebar links
        sidebarLinks.forEach(link => link.classList.remove('active'));
        // Add active class to the clicked link
        usersLink.classList.add('active');

        // Add event listener for "More" button in New Users section
        const moreUserButton = document.getElementById('more-user');
        if (moreUserButton) {
            moreUserButton.addEventListener('click', function(event) {
                event.preventDefault();
                window.location.href = '../signup.html'; // Redirect to signup.html
            });
        }
    });
}

const sections = {
    'dashboard-link': '<h1>Dashboard</h1>',
    'users-link': document.querySelector('.new-users').outerHTML,
    'history-link': '<h1>File Management</h1>',
    'analytics-link': '<h1>Analytics</h1>',
    'tickets-link': `
        <h1>Tickets</h1>
        <div class="tickets">
            <div class="ticket">
                <h3>Issue with Login</h3>
                <p>User is unable to login with correct credentials.</p>
                <span class="status open">Open</span>
            </div>
            <div class="ticket">
                <h3>Payment Failure</h3>
                <p>Payment gateway is not processing transactions.</p>
                <span class="status in-progress">In Progress</span>
            </div>
            <div class="ticket">
                <h3>Bug in Dashboard</h3>
                <p>Dashboard is not displaying recent activities.</p>
                <span class="status resolved">Resolved</span>
            </div>
            <div class="ticket">
                <h3>Feature Request</h3>
                <p>User requested a new feature for reporting.</p>
                <span class="status open">Open</span>
            </div>
        </div>
    `,
    'sale-list-link': `
        <h1>Sale List</h1>
        <div class="sale-list">
            <div class="sale-item">
                <h3>Product A</h3>
                <p>Sold: 150 units</p>
                <span class="status success">Completed</span>
            </div>
            <div class="sale-item">
                <h3>Product B</h3>
                <p>Sold: 75 units</p>
                <span class="status warning">Pending</span>
            </div>
            <div class="sale-item">
                <h3>Product C</h3>
                <p>Sold: 200 units</p>
                <span class="status success">Completed</span>
            </div>
            <div class="sale-item">
                <h3>Product D</h3>
                <p>Sold: 50 units</p>
                <span class="status danger">Cancelled</span>
            </div>
        </div>
    `,
    'reports-link': `
        <h1>Reports</h1>
        <div class="reports">
            <div class="report-item">
                <h3>Monthly Sales Report</h3>
                <p>Summary of sales for the month.</p>
                <span class="status success">Completed</span>
            </div>
            <div class="report-item">
                <h3>Customer Feedback</h3>
                <p>Analysis of customer feedback and reviews.</p>
                <span class="status in-progress">In Progress</span>
            </div>
            <div class="report-item">
                <h3>Website Traffic</h3>
                <p>Report on website traffic and user behavior.</p>
                <span class="status pending">Pending</span>
            </div>
            <div class="report-item">
                <h3>Financial Overview</h3>
                <p>Quarterly financial performance and projections.</p>
                <span class="status success">Completed</span>
            </div>
        </div>
    `,
    'settings-link': `
        <h1>Settings</h1>
        <div class="settings">
            <div class="setting-item">
                <h3>Profile Settings</h3>
                <p>Update your profile information.</p>
                <button class="btn">Edit</button>
            </div>
            <div class="setting-item">
                <h3>Account Security</h3>
                <p>Manage your account security settings.</p>
                <button class="btn">Manage</button>
            </div>
            <div class="setting-item">
                <h3>Notification Preferences</h3>
                <p>Set your notification preferences.</p>
                <button class="btn">Update</button>
            </div>
            <div class="setting-item">
                <h3>Privacy Settings</h3>
                <p>Control your privacy settings.</p>
                <button class="btn">Configure</button>
            </div>
        </div>
    `
};

sidebarLinks.forEach(link => {
    link.addEventListener('click', function(event) {
        event.preventDefault();
        // Remove active class from all sidebar links
        sidebarLinks.forEach(link => link.classList.remove('active'));
        // Add active class to the clicked link
        link.classList.add('active');
        // Update main content
        mainContent.innerHTML = sections[link.id] || '<h1>Content Not Found</h1>';
    });
});

const dashboardLink = document.getElementById('dashboard-link');
const recentOrdersSection = document.querySelector('.recent-orders');

if (dashboardLink && recentOrdersSection && mainContent) {
    dashboardLink.addEventListener('click', function(event) {
        event.preventDefault();
        mainContent.innerHTML = ''; // Clear main content
        mainContent.appendChild(recentOrdersSection); // Append only the recent orders section

        // Remove active class from all sidebar links
        sidebarLinks.forEach(link => link.classList.remove('active'));
        // Add active class to the clicked link
        dashboardLink.classList.add('active');
    });
}

const historyLink = document.getElementById('history-link');
const fileManagementSection = document.querySelector('.history');

if (historyLink && fileManagementSection && mainContent) {
    historyLink.addEventListener('click', function(event) {
        event.preventDefault();
        mainContent.innerHTML = ''; // Clear main content
        mainContent.appendChild(fileManagementSection); // Append only the file management section

        // Remove active class from all sidebar links
        sidebarLinks.forEach(link => link.classList.remove('active'));
        // Add active class to the clicked link
        historyLink.classList.add('active');
    });
}

// Add event listeners for file management functionalities
document.getElementById('upload-box').addEventListener('dragover', function(event) {
    event.preventDefault();
    event.stopPropagation();
    this.classList.add('dragging');
});

document.getElementById('upload-box').addEventListener('dragleave', function(event) {
    event.preventDefault();
    event.stopPropagation();
    this.classList.remove('dragging');
});

document.getElementById('upload-box').addEventListener('drop', function(event) {
    event.preventDefault();
    event.stopPropagation();
    this.classList.remove('dragging');
    const files = event.dataTransfer.files;
    handleFiles(files);
});

document.getElementById('file-input').addEventListener('change', function(event) {
    const files = event.target.files;
    handleFiles(files);
});

document.getElementById('file-list').addEventListener('click', function(event) {
    const fileItem = event.target.closest('.file-item');
    let file = fileItem.file;

    if (event.target.classList.contains('share')) {
        if (!file) {
            customAlert("File data is missing or invalid.", '#28a745');
            return;
        }

        if (navigator.share) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const fileBlob = new Blob([e.target.result], { type: file.type });
                const sharedFile = new File([fileBlob], file.name, { type: file.type });
                navigator.share({
                    title: 'Share File',
                    text: 'Check out this file!',
                    files: [sharedFile],
                }).then(() => {
                    console.log('File shared successfully.');
                }).catch((error) => {
                    console.error('Error sharing file: ' + error);
                    customAlert('Sharing failed. Please try again.', '#28a745');
                });
            };
            reader.readAsArrayBuffer(file);
        } else {
            customAlert("Sharing is not supported in this browser.", '#28a745');
        }
    } else if (event.target.classList.contains('delete')) {
        fileItem.remove();
        updateHistory();
        customAlert('File deleted successfully.', '#28a745');
    } else if (event.target.classList.contains('fa-download')) {
        const downloadIcon = event.target;
        downloadIcon.href = URL.createObjectURL(file);
        downloadIcon.download = file.name;
        downloadIcon.click();
    } else if (event.target.classList.contains('rename')) {
        const newName = prompt('Enter the new file name (including extension):');
        if (newName && newName.includes('.')) {
            fileItem.querySelector('.file-info p').textContent = newName;
            const updatedFile = new File([file], newName, { type: file.type });
            fileItem.file = updatedFile;
            file = updatedFile; // Update the file reference
            customAlert('File renamed successfully.', '#28a745');
        } else {
            customAlert('Please include a valid file extension.', '#28a745');
        }
    }
});

function handleFiles(files) {
    const fileList = document.getElementById('file-list');
    for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const fileItem = document.createElement('div');
        fileItem.className = 'file-item';

        const fileInfo = document.createElement('div');
        fileInfo.className = 'file-info';

        const fileCheckbox = document.createElement('input');
        fileCheckbox.type = 'checkbox';
        fileCheckbox.className = 'file-checkbox';

        const fileThumbnail = document.createElement('img');
        fileThumbnail.alt = `Thumbnail of ${file.name}`;
        fileThumbnail.height = 30;
        fileThumbnail.width = 30;
        fileThumbnail.src = URL.createObjectURL(file);

        const fileName = document.createElement('p');
        fileName.textContent = file.name;

        const fileStatus = document.createElement('p');
        fileStatus.className = 'status';
        fileStatus.textContent = 'Uploaded';

        const fileSize = document.createElement('p');
        fileSize.textContent = `${(file.size / (1024 * 1024)).toFixed(1)} Mb`;

        fileInfo.appendChild(fileCheckbox);
        fileInfo.appendChild(fileThumbnail);
        fileInfo.appendChild(fileName);
        fileInfo.appendChild(fileStatus);
        fileInfo.appendChild(fileSize);

        const fileActions = document.createElement('div');
        fileActions.className = 'file-actions';

        const downloadIcon = document.createElement('a');
        downloadIcon.className = 'fas fa-download';

        const shareIcon = document.createElement('i');
        shareIcon.className = 'fas fa-share share';

        const renameIcon = document.createElement('i');
        renameIcon.className = 'fas fa-edit rename';

        const deleteIcon = document.createElement('i');
        deleteIcon.className = 'fas fa-trash delete';

        fileActions.appendChild(downloadIcon);
        fileActions.appendChild(shareIcon);
        fileActions.appendChild(renameIcon);
        fileActions.appendChild(deleteIcon);

        fileItem.appendChild(fileInfo);
        fileItem.appendChild(fileActions);

        fileList.appendChild(fileItem);

        fileItem.file = new File([file], file.name, { type: file.type });
    }
    updateHistory();
}

function updateHistory() {
    const fileList = document.getElementById('file-list');
    if (fileList.children.length === 0) {
        fileList.innerHTML = '<p>No files uploaded.</p>';
    }
}

// Ensure the event listener for "More" button is added on page load
document.addEventListener('DOMContentLoaded', function() {
    const shareButtons = document.querySelectorAll('.file-actions .share');
    shareButtons.forEach(button => {
        button.addEventListener('click', function() {
            customAlert('Share functionality is not implemented yet.', '#28a745');
        });
    });

    const clearAllBtn = document.getElementById('clear-all-btn');
    clearAllBtn.addEventListener('click', function() {
        const fileList = document.getElementById('file-list');
        fileList.innerHTML = '';
        updateHistory();
        customAlert('All files cleared.', '#28a745');
    });

    const downloadAllBtn = document.getElementById('download-all-btn');
    downloadAllBtn.addEventListener('click', function() {
        const fileItems = document.querySelectorAll('.file-item .file-checkbox:checked');
        fileItems.forEach(item => {
            const downloadIcon = item.closest('.file-item').querySelector('.fa-download');
            if (downloadIcon) {
                downloadIcon.click();
            }
        });
        customAlert('All files downloaded.', '#28a745');
    });

    const shareAllBtn = document.getElementById('share-all-btn');
    shareAllBtn.addEventListener('click', function() {
        const fileItems = document.querySelectorAll('.file-item .file-checkbox:checked');
        fileItems.forEach(item => {
            const shareIcon = item.closest('.file-item').querySelector('.share');
            if (shareIcon) {
                shareIcon.click();
            }
        });
        customAlert('All files shared.', '#28a745');
    });

    const renameAllBtn = document.getElementById('rename-all-btn');
    renameAllBtn.addEventListener('click', function() {
        const fileItems = document.querySelectorAll('.file-item .file-checkbox:checked');
        fileItems.forEach(item => {
            const fileName = prompt('Enter the new file name (including extension):');
            if (fileName && fileName.includes('.')) {
                const selectedFile = item.closest('.file-item').querySelector('.file-info p');
                if (selectedFile) {
                    selectedFile.textContent = fileName;
                    const fileItem = item.closest('.file-item');
                    const updatedFile = new File([fileItem.file], fileName, { type: fileItem.file.type });
                    fileItem.file = updatedFile;
                    customAlert('All files renamed.', '#28a745');
                } else {
                    customAlert('No file selected to rename.', '#28a745');
                }
            } else {
                customAlert('Please include a valid file extension.', '#28a745');
            }
        });
    });

    const removeAllBtn = document.getElementById('remove-all-btn');
    removeAllBtn.addEventListener('click', function() {
        const fileItems = document.querySelectorAll('.file-item .file-checkbox:checked');
        fileItems.forEach(item => {
            item.closest('.file-item').remove();
        });
        updateHistory();
        customAlert('All files removed.', '#28a745');
    });

    const changeThemeBtn = document.getElementById('change-theme-btn');
    changeThemeBtn.addEventListener('click', function() {
        document.body.classList.toggle('dark-theme');
        customAlert('Theme changed.', '#28a745');
    });

    const allFilesBtn = document.getElementById('all-files-btn');
    allFilesBtn.addEventListener('click', function(event) {
        event.preventDefault();
        document.getElementById('all-files-section').scrollIntoView({ behavior: 'smooth' });
        customAlert('Navigating to all files section.', '#28a745');
    });

    const moreUserButton = document.getElementById('more-user');
    if (moreUserButton) {
        moreUserButton.addEventListener('click', function(event) {
            event.preventDefault();
            customAlert('Redirecting to signup...', '#28a745');
            setTimeout(() => {
                window.location.href = '../signup.html'; // Redirect to signup.html
            }, 2000); // Reduced delay to 2 seconds
        });
    }
});

Orders.forEach(order => {
    const tr = document.createElement('tr');
    const trContent = `
        <td>${order.productName}</td>
        <td>${order.productNumber}</td>
        <td>${order.paymentStatus}</td>
        <td class="${order.status === 'Declined' ? 'danger' : order.status === 'Pending' ? 'warning' : 'primary'}">${order.status}</td>
        <td class="primary">Details</td>
    `;
    tr.innerHTML = trContent;
    document.querySelector('table tbody').appendChild(tr);
});

const analyticsLink = document.getElementById('analytics-link');
const mainContentHTML = `
    <h1>Analytics</h1>
    <div class="analyse">
        <div class="sales">
            <div class="status">
                <div class="info">
                    <h3>Total Sales</h3>
                    <h1>$65,024</h1>
                </div>
                <div class="progresss">
                    <svg>
                        <circle cx="38" cy="38" r="36"></circle>
                    </svg>
                    <div class="percentage">
                        <p>+81%</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="visits">
            <div class="status">
                <div class="info">
                    <h3>Site Visit</h3>
                    <h1>24,981</h1>
                </div>
                <div class="progresss">
                    <svg>
                        <circle cx="38" cy="38" r="36"></circle>
                    </svg>
                    <div class="percentage">
                        <p>-48%</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="searches">
            <div class="status">
                <div class="info">
                    <h3>Searches</h3>
                    <h1>14,147</h1>
                </div>
                <div class="progresss">
                    <svg>
                        <circle cx="38" cy="38" r="36"></circle>
                    </svg>
                    <div class="percentage">
                        <p>+21%</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="history">
        <h1>File Management</h1>
        <div class="upload-box" id="upload-box" onclick="document.getElementById('file-input').click();">
            <i class="fas fa-cloud-upload-alt"></i>
            <p>Click or drag your files here</p>
            <input type="file" id="file-input" multiple style="display: none;">
        </div>
        <div class="file-list" id="file-list">
            <!-- No built-in files -->
        </div>
        <div class="share-options-container"></div>
        <div class="download-all">
            <button id="download-all-btn">Download</button>
            <button id="clear-all-btn">Clear</button>
            <button id="share-all-btn">Share</button>
            <button id="rename-all-btn">Rename</button>
            <button id="remove-all-btn">Remove</button>
        </div>
    </div>
    <div class="new-users">
        <h2>New Users</h2>
        <div class="user-list">
            <div class="user">
                <img src="images/profile-2.jpg">
                <h2>Jack</h2>
                <p>54 Min Ago</p>
            </div>
            <div class="user">
                <img src="images/profile-3.jpg">
                <h2>Amir</h2>
                <p>3 Hours Ago</p>
            </div>
            <div class="user">
                <img src="images/profile-4.jpg">
                <h2>Ember</h2>
                <p>6 Hours Ago</p>
            </div>
            <div class="user" id="more-user">
                <img src="images/plus.png">
                <h2>More</h2>
                <p>New User</p>
            </div>
        </div>
    </div>
    <div class="recent-orders">
        <h2>Recent Orders</h2>
        <table>
            <thead>
                <tr>
                    <th>Course Name</th>
                    <th>Course Number</th>
                    <th>Payment</th>
                    <th>Status</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <!-- Orders will be dynamically added here -->
            </tbody>
        </table>
        <a href="#">Show All</a>
    </div>
`;

if (analyticsLink && mainContent) {
    analyticsLink.addEventListener('click', function(event) {
        event.preventDefault();
        mainContent.innerHTML = mainContentHTML;

        // Remove active class from all sidebar links
        sidebarLinks.forEach(link => link.classList.remove('active'));
        // Add active class to the clicked link
        analyticsLink.classList.add('active');

        // Reinitialize event listeners for file management functionalities
        document.getElementById('upload-box').addEventListener('dragover', function(event) {
            event.preventDefault();
            event.stopPropagation();
            this.classList.add('dragging');
        });

        document.getElementById('upload-box').addEventListener('dragleave', function(event) {
            event.preventDefault();
            event.stopPropagation();
            this.classList.remove('dragging');
        });

        document.getElementById('upload-box').addEventListener('drop', function(event) {
            event.preventDefault();
            event.stopPropagation();
            this.classList.remove('dragging');
            const files = event.dataTransfer.files;
            handleFiles(files);
        });

        document.getElementById('file-input').addEventListener('change', function(event) {
            const files = event.target.files;
            handleFiles(files);
        });

        document.getElementById('file-list').addEventListener('click', function(event) {
            const fileItem = event.target.closest('.file-item');
            let file = fileItem.file;

            if (event.target.classList.contains('share')) {
                if (!file) {
                    customAlert("File data is missing or invalid.", '#28a745');
                    return;
                }

                if (navigator.share) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        const fileBlob = new Blob([e.target.result], { type: file.type });
                        const sharedFile = new File([fileBlob], file.name, { type: file.type });
                        navigator.share({
                            title: 'Share File',
                            text: 'Check out this file!',
                            files: [sharedFile],
                        }).then(() => {
                            console.log('File shared successfully.');
                        }).catch((error) => {
                            console.error('Error sharing file: ' + error);
                            customAlert('Sharing failed. Please try again.', '#28a745');
                        });
                    };
                    reader.readAsArrayBuffer(file);
                } else {
                    customAlert("Sharing is not supported in this browser.", '#28a745');
                }
            } else if (event.target.classList.contains('delete')) {
                fileItem.remove();
                updateHistory();
                customAlert('File deleted successfully.', '#28a745');
            } else if (event.target.classList.contains('fa-download')) {
                const downloadIcon = event.target;
                downloadIcon.href = URL.createObjectURL(file);
                downloadIcon.download = file.name;
                downloadIcon.click();
            } else if (event.target.classList.contains('rename')) {
                const newName = prompt('Enter the new file name (including extension):');
                if (newName && newName.includes('.')) {
                    fileItem.querySelector('.file-info p').textContent = newName;
                    const updatedFile = new File([file], newName, { type: file.type });
                    fileItem.file = updatedFile;
                    file = updatedFile; // Update the file reference
                    customAlert('File renamed successfully.', '#28a745');
                } else {
                    customAlert('Please include a valid file extension.', '#28a745');
                }
            }
        });

        document.getElementById('clear-all-btn').addEventListener('click', function() {
            const fileList = document.getElementById('file-list');
            fileList.innerHTML = '';
            updateHistory();
            customAlert('All files cleared.', '#28a745');
        });

        document.getElementById('download-all-btn').addEventListener('click', function() {
            const fileItems = document.querySelectorAll('.file-item .file-checkbox:checked');
            fileItems.forEach(item => {
                const downloadIcon = item.closest('.file-item').querySelector('.fa-download');
                if (downloadIcon) {
                    downloadIcon.click();
                }
            });
            customAlert('All files downloaded.', '#28a745');
        });

        document.getElementById('share-all-btn').addEventListener('click', function() {
            const fileItems = document.querySelectorAll('.file-item .file-checkbox:checked');
            fileItems.forEach(item => {
                const shareIcon = item.closest('.file-item').querySelector('.share');
                if (shareIcon) {
                    shareIcon.click();
                }
            });
            customAlert('All files shared.', '#28a745');
        });

        document.getElementById('rename-all-btn').addEventListener('click', function() {
            const fileItems = document.querySelectorAll('.file-item .file-checkbox:checked');
            fileItems.forEach(item => {
                const fileName = prompt('Enter the new file name (including extension):');
                if (fileName && fileName.includes('.')) {
                    const selectedFile = item.closest('.file-item').querySelector('.file-info p');
                    if (selectedFile) {
                        selectedFile.textContent = fileName;
                        const fileItem = item.closest('.file-item');
                        const updatedFile = new File([fileItem.file], fileName, { type: fileItem.file.type });
                        fileItem.file = updatedFile;
                        customAlert('All files renamed.', '#28a745');
                    } else {
                        customAlert('No file selected to rename.', '#28a745');
                    }
                } else {
                    customAlert('Please include a valid file extension.', '#28a745');
                }
            });
        });

        document.getElementById('remove-all-btn').addEventListener('click', function() {
            const fileItems = document.querySelectorAll('.file-item .file-checkbox:checked');
            fileItems.forEach(item => {
                item.closest('.file-item').remove();
            });
            updateHistory();
            customAlert('All files removed.', '#28a745');
        });

        function handleFiles(files) {
            const fileList = document.getElementById('file-list');
            for (let i = 0; i < files.length; i++) {
                const file = files[i];
                const fileItem = document.createElement('div');
                fileItem.className = 'file-item';

                const fileInfo = document.createElement('div');
                fileInfo.className = 'file-info';

                const fileCheckbox = document.createElement('input');
                fileCheckbox.type = 'checkbox';
                fileCheckbox.className = 'file-checkbox';

                const fileThumbnail = document.createElement('img');
                fileThumbnail.alt = `Thumbnail of ${file.name}`;
                fileThumbnail.height = 30;
                fileThumbnail.width = 30;
                fileThumbnail.src = URL.createObjectURL(file);

                const fileName = document.createElement('p');
                fileName.textContent = file.name;

                const fileStatus = document.createElement('p');
                fileStatus.className = 'status';
                fileStatus.textContent = 'Uploaded';

                const fileSize = document.createElement('p');
                fileSize.textContent = `${(file.size / (1024 * 1024)).toFixed(1)} Mb`;

                fileInfo.appendChild(fileCheckbox);
                fileInfo.appendChild(fileThumbnail);
                fileInfo.appendChild(fileName);
                fileInfo.appendChild(fileStatus);
                fileInfo.appendChild(fileSize);

                const fileActions = document.createElement('div');
                fileActions.className = 'file-actions';

                const downloadIcon = document.createElement('a');
                downloadIcon.className = 'fas fa-download';

                const shareIcon = document.createElement('i');
                shareIcon.className = 'fas fa-share share';

                const renameIcon = document.createElement('i');
                renameIcon.className = 'fas fa-edit rename';

                const deleteIcon = document.createElement('i');
                deleteIcon.className = 'fas fa-trash delete';

                fileActions.appendChild(downloadIcon);
                fileActions.appendChild(shareIcon);
                fileActions.appendChild(renameIcon);
                fileActions.appendChild(deleteIcon);

                fileItem.appendChild(fileInfo);
                fileItem.appendChild(fileActions);

                fileList.appendChild(fileItem);

                fileItem.file = new File([file], file.name, { type: file.type });
            }
            updateHistory();
        }

        function updateHistory() {
            const fileList = document.getElementById('file-list');
            if (fileList.children.length === 0) {
                fileList.innerHTML = '<p>No files uploaded.</p>';
            }
        }

        Orders.forEach(order => {
            const tr = document.createElement('tr');
            const trContent = `
                <td>${order.productName}</td>
                <td>${order.productNumber}</td>
                <td>${order.paymentStatus}</td>
                <td class="${order.status === 'Declined' ? 'danger' : order.status === 'Pending' ? 'warning' : 'primary'}">${order.status}</td>
                <td class="primary">Details</td>
            `;
            tr.innerHTML = trContent;
            document.querySelector('table tbody').appendChild(tr);
        });
    });
}

const profile = document.querySelector('.profile');
const dropdownMenu = document.createElement('div');
dropdownMenu.classList.add('dropdown-menu');
dropdownMenu.innerHTML = `
    <p>Hey, Admin</p>
    <p id="profile-link">Profile</p>
    <p id="profile-settings-link">Settings</p>
    <p id="profile-logout-link">Logout</p>
`;
profile.appendChild(dropdownMenu);

const profileLink = document.getElementById('profile-link');
const profileSettingsLink = document.getElementById('profile-settings-link');
const profileLogoutLink = document.getElementById('profile-logout-link');
const settingsLink = document.getElementById('settings-link');
const logoutLink = document.querySelector('.sidebar a[href="#"]:last-child');

if (profileLink && usersLink) {
    profileLink.addEventListener('click', function(event) {
        event.preventDefault();
        usersLink.click();
    });
}

if (profileSettingsLink && settingsLink) {
    profileSettingsLink.addEventListener('click', function(event) {
        event.preventDefault();
        settingsLink.click();
    });
}

if (profileLogoutLink && logoutLink) {
    profileLogoutLink.addEventListener('click', function(event) {
        event.preventDefault();
        logoutLink.click();
        window.location.href = '../index.html'; // Redirect to index.html
    });
}

function customAlert(message, color) {
    const alertBox = document.createElement('div');
    alertBox.style.position = 'fixed';
    alertBox.style.top = '50%';
    alertBox.style.left = '50%';
    alertBox.style.transform = 'translate(-50%, -50%)';
    alertBox.style.backgroundColor = color;
    alertBox.style.color = '#fff';
    alertBox.style.padding = '20px';
    alertBox.style.borderRadius = '5px';
    alertBox.style.boxShadow = '0 0 10px rgba(0, 0, 0, 0.1)';
    alertBox.style.zIndex = '1000';
    alertBox.textContent = message;

    document.body.appendChild(alertBox);

    setTimeout(() => {
        document.body.removeChild(alertBox);
    }, 2000); // Reduced delay to 2 seconds
}