const inputs = document.querySelectorAll(".input");

function addcl(){
	let parent = this.parentNode.parentNode;
	parent.classList.add("focus");
}

function remcl(){
	let parent = this.parentNode.parentNode;
	if(this.value == ""){
		parent.classList.remove("focus");
	}
}

inputs.forEach(input => {
	input.addEventListener("focus", addcl);
	input.addEventListener("blur", remcl);
	// Apply focus class if input has value
	if (input.value !== "") {
		let parent = input.parentNode.parentNode;
		parent.classList.add("focus");
	}
});

window.addEventListener('load', () => {
	inputs.forEach(input => {
		if (input.value !== "") {
			let parent = input.parentNode.parentNode;
			parent.classList.add("focus");
		}
	});
});

const loginForm = document.getElementById('loginForm');
if (loginForm) {
	const rememberMeCheckbox = document.querySelector('input[name="remember"]');
	const storedUsernameOrEmail = localStorage.getItem('rememberedUsernameOrEmail');
	const storedPassword = localStorage.getItem('rememberedPassword');

	if (storedUsernameOrEmail && storedPassword) {
		document.querySelector('.input-div.one .input').value = storedUsernameOrEmail;
		document.querySelector('.input-div.pass .input').value = storedPassword;
		rememberMeCheckbox.checked = true;
	}

	function customAlert(message, color) {
		const alertBox = document.createElement('div');
		alertBox.style.position = 'fixed';
		alertBox.style.top = '50%';
		alertBox.style.left = '50%';
		alertBox.style.transform = 'translate(-50%, -50%)';
		alertBox.style.backgroundColor = color;
		alertBox.style.color = '#fff';
		alertBox.style.padding = '20px';
		alertBox.style.borderRadius = '5px';
		alertBox.style.boxShadow = '0 0 10px rgba(0, 0, 0, 0.1)';
		alertBox.style.zIndex = '1000';
		alertBox.textContent = message;

		document.body.appendChild(alertBox);

		setTimeout(() => {
			document.body.removeChild(alertBox);
		}, 2000); // Reduced delay to 2 seconds
	}

	loginForm.addEventListener('submit', function(event) {
		event.preventDefault();
		const usernameOrEmail = document.querySelector('.input-div.one .input').value;
		const password = document.querySelector('.input-div.pass .input').value;
		const storedUserData = JSON.parse(localStorage.getItem('userData'));

		if (usernameOrEmail === '' || password === '') {
			customAlert('Please fill in both username/email and password.', '#28a745');
		} else if (storedUserData && (storedUserData.username === usernameOrEmail || storedUserData.email === usernameOrEmail) && storedUserData.password === password) {
			if (rememberMeCheckbox.checked) {
				localStorage.setItem('rememberedUsernameOrEmail', usernameOrEmail);
				localStorage.setItem('rememberedPassword', password);
			} else {
				localStorage.removeItem('rememberedUsernameOrEmail');
				localStorage.removeItem('rememberedPassword');
			}
			customAlert('Login successful', '#28a745'); // Custom alert with green color
			setTimeout(() => {
				window.location.href = 'Dashboard/interface.html'; // Redirect to interface.html
			}, 2000); // Reduced delay to 2 seconds
		} else {
			customAlert('Invalid username/email or password.', '#28a745');
		}
	});
}

const signupForm = document.getElementById('signupForm');
if (signupForm) {
	signupForm.addEventListener('submit', function(event) {
		event.preventDefault();
		const username = document.querySelector('.input-div.one .input').value;
		const email = document.querySelector('.input-div.one input[type="email"][name="email"]').value;
		const password = document.querySelector('#signupPassword').value;
		const confirmPassword = document.querySelector('#confirmSignupPassword').value;
		const contactPhone = document.querySelector('.input-div.one input[type="text"][name="contactPhone"]').value;
		const homeAddress = document.querySelector('.input-div.one input[type="text"][name="homeAddress"]').value;
		const passwordQuestion = document.querySelector('select[name="passwordQuestion"]').value;
		const passwordAnswer = document.querySelector('.input-div.one input[type="text"][name="passwordAnswer"]').value;
		const hobbies = document.querySelector('.input-div.one input[type="text"][name="hobbies"]').value;
		const gender = document.querySelector('.input-div.one input[type="radio"][name="gender"]:checked');

		const passwordStrength = document.getElementById('passwordStrength');
		const passwordMatch = document.getElementById('passwordMatch');

		if (username === '' || email === '' || password === '' || confirmPassword === '' || contactPhone === '' || homeAddress === '' || passwordQuestion === '' || passwordAnswer === '' || hobbies === '' || !gender) {
			customAlert('Please fill in all required fields.', '#28a745');
		} else if (!/^[\d+]+$/.test(contactPhone)) {
			customAlert('Contact Phone must contain only numbers and the "+" character.', '#28a745');
		} else if (password.length < 8 || !/[!@#$%^&*]/.test(password)) {
			passwordStrength.textContent = 'Weak Password: Must be at least 8 characters and contain a special character';
			passwordStrength.style.color = 'red';
		} else if (password !== confirmPassword) {
			passwordMatch.textContent = 'Passwords do not match';
			passwordMatch.style.color = 'red';
		} else {
			passwordStrength.textContent = 'Strong Password';
			passwordStrength.style.color = 'green';
			passwordMatch.textContent = '';
			// Save user data to local storage
			const userData = {
				username: username,
				email: email,
				password: password,
				contactPhone: contactPhone,
				homeAddress: homeAddress,
				passwordQuestion: passwordQuestion,
				passwordAnswer: passwordAnswer,
				hobbies: hobbies,
				gender: gender.value
			};
			localStorage.setItem('userData', JSON.stringify(userData));
			customAlert('Signup Submitted', '#28a745');
			setTimeout(() => {
				window.location.href = 'index.html'; // Navigate to login page
			}, 3000);
		}
	});

	const contactPhoneInput = document.querySelector('.input-div.one input[type="text"][name="contactPhone"]');
	if (contactPhoneInput) {
		contactPhoneInput.addEventListener('input', function() {
			if (/[^0-9+]/.test(this.value)) {
				customAlert('Contact Phone must contain only numbers and the "+" character.', '#28a745');
				this.value = this.value.replace(/[^0-9+]/g, '');
			}
		});
	}

	const signupPassword = document.getElementById('signupPassword');
	const confirmSignupPassword = document.getElementById('confirmSignupPassword');
	const passwordStrength = document.getElementById('passwordStrength');
	const passwordMatch = document.getElementById('passwordMatch');

	if (signupPassword && confirmSignupPassword) {
		signupPassword.addEventListener('input', function() {
			if (signupPassword.value.length < 8 || !/[!@#$%^&*]/.test(signupPassword.value)) {
				passwordStrength.textContent = 'Weak Password: Must be at least 8 characters and contain a special character';
				passwordStrength.style.color = 'red';
			} else {
				passwordStrength.textContent = 'Strong Password';
				passwordStrength.style.color = 'green';
			}
		});

		confirmSignupPassword.addEventListener('input', function() {
			if (signupPassword.value !== confirmSignupPassword.value) {
				passwordMatch.textContent = 'Passwords do not match';
				passwordMatch.style.color = 'red';
			} else {
				passwordMatch.textContent = '';
			}
		});
	}
}

const clearSelection = document.getElementById('clearSelection');
const passwordQuestionSelect = document.querySelector('select[name="passwordQuestion"]');

if (clearSelection && passwordQuestionSelect) {
	clearSelection.style.display = 'none'; // Hide 'x' button initially

	passwordQuestionSelect.addEventListener('change', function () {
		if (this.value) {
			clearSelection.style.display = 'block'; // Show 'x' button when a question is selected
		} else {
			clearSelection.style.display = 'none'; // Hide 'x' button when no question is selected
		}
	});

	clearSelection.addEventListener('click', function () {
		passwordQuestionSelect.selectedIndex = 0;
		clearSelection.style.display = 'none'; // Hide 'x' button after clearing selection
	});
}

const togglePassword = document.getElementById('togglePassword');
const password = document.getElementById('password');

if (togglePassword && password) {
	togglePassword.addEventListener('click', function () {
		const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
		password.setAttribute('type', type);
		this.classList.toggle('fa-eye-slash');
	});
}

const toggleSignupPassword = document.getElementById('toggleSignupPassword');
const signupPassword = document.getElementById('signupPassword');

if (toggleSignupPassword && signupPassword) {
	toggleSignupPassword.addEventListener('click', function () {
		const type = signupPassword.getAttribute('type') === 'password' ? 'text' : 'password';
		signupPassword.setAttribute('type', type);
		this.classList.toggle('fa-eye-slash');
	});
}

const toggleConfirmSignupPassword = document.getElementById('toggleConfirmSignupPassword');
const confirmSignupPassword = document.getElementById('confirmSignupPassword');

if (toggleConfirmSignupPassword && confirmSignupPassword) {
	toggleConfirmSignupPassword.addEventListener('click', function () {
		const type = confirmSignupPassword.getAttribute('type') === 'password' ? 'text' : 'password';
		confirmSignupPassword.setAttribute('type', type);
		this.classList.toggle('fa-eye-slash');
	});
}

const forgotPasswordForm = document.getElementById('forgotPasswordForm');
if (forgotPasswordForm) {
	const step1 = document.getElementById('step1');
	const step2 = document.getElementById('step2');
	const step3 = document.getElementById('step3');
	const verifyButton = document.getElementById('verifyButton');
	const submitAnswerButton = document.getElementById('submitAnswerButton');
	const forgotUsername = document.getElementById('forgotUsername');
	const forgotEmail = document.getElementById('forgotEmail');
	const retrievalQuestion = document.getElementById('retrievalQuestion');
	const retrievalAnswer = document.getElementById('retrievalAnswer');
	const newPassword = document.getElementById('newPassword');
	const confirmNewPassword = document.getElementById('confirmNewPassword');
	const newPasswordStrength = document.getElementById('newPasswordStrength');
	const newPasswordMatch = document.getElementById('newPasswordMatch');
	const toggleNewPassword = document.getElementById('toggleNewPassword');
	const toggleConfirmNewPassword = document.getElementById('toggleConfirmNewPassword');

	verifyButton.addEventListener('click', function() {
		const storedUserData = JSON.parse(localStorage.getItem('userData'));
		if (storedUserData && storedUserData.username === forgotUsername.value && storedUserData.email === forgotEmail.value) {
			retrievalQuestion.textContent = getQuestionText(storedUserData.passwordQuestion);
			step1.style.display = 'none';
			step2.style.display = 'block';
		} else {
			customAlert('Invalid username or email.', '#28a745');
		}
	});

	submitAnswerButton.addEventListener('click', function() {
		const storedUserData = JSON.parse(localStorage.getItem('userData'));
		if (storedUserData && storedUserData.passwordAnswer === retrievalAnswer.value) {
			step2.style.display = 'none';
			step3.style.display = 'block';
		} else {
			customAlert('Incorrect answer to the password retrieval question.', '#28a745');
		}
	});

	forgotPasswordForm.addEventListener('submit', function(event) {
		event.preventDefault();
		if (newPassword.value.length < 8 || !/[!@#$%^&*]/.test(newPassword.value)) {
			newPasswordStrength.textContent = 'Weak Password: Must be at least 8 characters and contain a special character';
			newPasswordStrength.style.color = 'red';
		} else if (newPassword.value !== confirmNewPassword.value) {
			newPasswordMatch.textContent = 'Passwords do not match';
			newPasswordMatch.style.color = 'red';
		} else {
			const storedUserData = JSON.parse(localStorage.getItem('userData'));
			storedUserData.password = newPassword.value;
			localStorage.setItem('userData', JSON.stringify(storedUserData));
			customAlert('Password reset successful.', '#28a745');
			setTimeout(() => {
				window.location.href = 'index.html'; // Navigate to login page
			}, 3000);
		}
	});

	if (newPassword && confirmNewPassword) {
		newPassword.addEventListener('input', function() {
			if (newPassword.value.length < 8 || !/[!@#$%^&*]/.test(newPassword.value)) {
				newPasswordStrength.textContent = 'Weak Password: Must be at least 8 characters and contain a special character';
				newPasswordStrength.style.color = 'red';
			} else {
				newPasswordStrength.textContent = 'Strong Password';
				newPasswordStrength.style.color = 'green';
			}
		});

		confirmNewPassword.addEventListener('input', function() {
			if (newPassword.value !== confirmNewPassword.value) {
				newPasswordMatch.textContent = 'Passwords do not match';
				newPasswordMatch.style.color = 'red';
			} else {
				newPasswordMatch.textContent = '';
			}
		});
	}

	if (toggleNewPassword && newPassword) {
		toggleNewPassword.addEventListener('click', function () {
			const type = newPassword.getAttribute('type') === 'password' ? 'text' : 'password';
			newPassword.setAttribute('type', type);
			this.classList.toggle('fa-eye-slash');
		});
	}

	if (toggleConfirmNewPassword && confirmNewPassword) {
		toggleConfirmNewPassword.addEventListener('click', function () {
			const type = confirmNewPassword.getAttribute('type') === 'password' ? 'text' : 'password';
			confirmNewPassword.setAttribute('type', type);
			this.classList.toggle('fa-eye-slash');
		});
	}
}

function getQuestionText(questionKey) {
	const questions = {
		petName: "What was your pet's name?",
		motherMaidenName: "What is your mother's maiden name?",
		firstSchool: "What was the name of your first school?",
		favoriteFood: "What is your favorite food?"
	};
	return questions[questionKey] || '';
}
